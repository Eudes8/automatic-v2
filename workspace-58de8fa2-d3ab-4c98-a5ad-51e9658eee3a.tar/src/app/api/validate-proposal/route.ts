import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const { proposalId } = await request.json()
    
    // Validation des données
    if (!proposalId) {
      return NextResponse.json(
        { error: 'ID de proposition manquant' },
        { status: 400 }
      )
    }

    // Simulation de validation de la proposition
    // Dans une vraie application, cela mettrait à jour la base de données
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    return NextResponse.json({
      success: true,
      message: 'Proposition validée avec succès',
      proposalId,
      status: 'validated',
      nextStep: 'contract_generation'
    })
    
  } catch (error) {
    console.error('Erreur lors de la validation de la proposition:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la validation de la proposition' },
      { status: 500 }
    )
  }
}