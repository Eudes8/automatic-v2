import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const { proposalId } = await request.json()
    
    // Validation des données
    if (!proposalId) {
      return NextResponse.json(
        { error: 'ID de proposition manquant' },
        { status: 400 }
      )
    }

    // Simulation de génération de contrat
    // Dans une vraie application, cela générerait un contrat personnalisé
    const contractData = {
      id: `CONTRAT-${Date.now()}`,
      proposalId,
      title: 'Contrat de Développement Logiciel',
      status: 'generated',
      createdAt: new Date().toISOString(),
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      downloadUrl: `/api/download-contract/${proposalId}`
    }
    
    // Simulation du temps de génération
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    return NextResponse.json({
      success: true,
      message: 'Contrat généré avec succès',
      contract: contractData
    })
    
  } catch (error) {
    console.error('Erreur lors de la génération du contrat:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la génération du contrat' },
      { status: 500 }
    )
  }
}