import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const projectData = await request.json()
    
    // Validation des données
    if (!projectData.projectName || !projectData.email || !projectData.description) {
      return NextResponse.json(
        { error: 'Données manquantes' },
        { status: 400 }
      )
    }

    // Génération du contenu de la proposition
    const proposalContent = generateProposalContent(projectData)
    
    // Pour l'instant, retournons le contenu en base64
    // Dans une implémentation réelle, vous pourriez utiliser une librairie comme jsPDF
    const base64Content = Buffer.from(proposalContent).toString('base64')
    
    return NextResponse.json({
      success: true,
      proposal: {
        filename: `proposition-${projectData.projectName.replace(/\s+/g, '-').toLowerCase()}.txt`,
        content: base64Content,
        mimeType: 'text/plain'
      }
    })
    
  } catch (error) {
    console.error('Erreur lors de la génération de la proposition:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la génération de la proposition' },
      { status: 500 }
    )
  }
}

function generateProposalContent(data: any): string {
  const currentDate = new Date().toLocaleDateString('fr-FR')
  
  return `
PROPOSITION DE DÉVELOPPEMENT LOGICIEL
=====================================

Date: ${currentDate}
Entreprise: AUTOMATIC
Contact: contact@automatic.dev
Téléphone: +33 1 23 45 67 89

INFORMATIONS CLIENT
==================

Nom du projet: ${data.projectName}
Entreprise: ${data.company}
Email: ${data.email}
Téléphone: ${data.phone || 'Non spécifié'}

DESCRIPTION DU PROJET
====================

${data.description}

SPÉCIFICATIONS TECHNIQUES
========================

Type de projet: ${getProjectTypeName(data.projectType)}
${data.platforms?.length > 0 ? `Plateformes: ${data.platforms.join(', ')}` : ''}

FONCTIONNALITÉS DEMANDÉES
========================

${data.features?.map((featureId: string) => getFeatureName(featureId)).join('\n') || 'Aucune fonctionnalité sélectionnée'}

${data.customFeatures ? `Fonctionnalités personnalisées:\n${data.customFeatures}\n` : ''}

EXIGENCES DE DESIGN
==================

Complexité: ${getDesignComplexityName(data.designComplexity)}
Éléments de marque: ${data.brandAssets ? 'Oui' : 'Non'}
Recherche utilisateur: ${data.userResearch ? 'Oui' : 'Non'}

EXIGENCES TECHNIQUES
===================

${data.technicalRequirements?.map((reqId: string) => getTechnicalRequirementName(reqId)).join('\n') || 'Aucune exigence technique spécifique'}

INTÉGRATIONS
============

${data.integrations?.map((intId: string) => getIntegrationName(intId)).join('\n') || 'Aucune intégration spécifiée'}

Préférence d'hébergement: ${data.hostingPreference || 'Non spécifiée'}

TIMELINE ET BUDGET
=================

Timeline souhaitée: ${getTimelineName(data.timeline)}
Budget approximatif: ${getBudgetName(data.budget)}
Priorité: ${getPriorityName(data.priority)}

ESTIMATION
==========

Prix estimé: ${calculateEstimatedPrice(data)}€
Durée estimée: ${calculateEstimatedTimeline(data)}

PROCHAINES ÉTAPES
================

1. Validation de cette proposition
2. Appel de clarification avec notre équipe technique
3. Signature du contrat
4. Lancement du projet

CONDITIONS COMMERCIALES
=====================

- Acompte de 30% à la signature
- Paiement de 40% à mi-projet
- Solde de 30% à la livraison
- Garantie de 3 mois sur les développements
- Support technique inclus pendant 6 mois

CONTACT
=======

Pour toute question ou pour accepter cette proposition:
Email: contact@automatic.dev
Téléphone: +33 1 23 45 67 89

Merci de votre confiance dans AUTOMATIC pour la réalisation de votre projet.
`
}

function getProjectTypeName(typeId: string): string {
  const types: Record<string, string> = {
    'web': 'Application Web',
    'mobile': 'Application Mobile',
    'saas': 'Plateforme SaaS',
    'ai': 'Intelligence Artificielle'
  }
  return types[typeId] || typeId
}

function getFeatureName(featureId: string): string {
  const features: Record<string, string> = {
    'user-auth': 'Authentification utilisateurs',
    'dashboard': 'Tableau de bord',
    'payments': 'Intégration paiements',
    'notifications': 'Notifications push/email',
    'analytics': 'Analytics et reporting',
    'api': 'API RESTful',
    'realtime': 'Fonctionnalités temps réel',
    'offline': 'Support offline',
    'social': 'Intégration réseaux sociaux',
    'multilingual': 'Support multilingue',
    'search': 'Recherche avancée',
    'file-upload': 'Gestion de fichiers'
  }
  return features[featureId] || featureId
}

function getDesignComplexityName(complexityId: string): string {
  const complexities: Record<string, string> = {
    'simple': 'Simple',
    'standard': 'Standard',
    'premium': 'Premium'
  }
  return complexities[complexityId] || complexityId
}

function getTechnicalRequirementName(reqId: string): string {
  const requirements: Record<string, string> = {
    'scalability': 'Haute scalabilité',
    'security': 'Sécurité avancée',
    'performance': 'Optimisation performance',
    'monitoring': 'Monitoring avancé',
    'backup': 'Sauvegarde automatique'
  }
  return requirements[reqId] || reqId
}

function getIntegrationName(intId: string): string {
  const integrations: Record<string, string> = {
    'stripe': 'Stripe',
    'google-analytics': 'Google Analytics',
    'mailchimp': 'Mailchimp',
    'slack': 'Slack',
    'salesforce': 'Salesforce',
    'hubspot': 'HubSpot'
  }
  return integrations[intId] || intId
}

function getTimelineName(timelineId: string): string {
  const timelines: Record<string, string> = {
    'urgent': 'Urgent (4-6 semaines)',
    'standard': 'Standard (8-12 semaines)',
    'flexible': 'Flexible (12-20 semaines)'
  }
  return timelines[timelineId] || timelineId
}

function getBudgetName(budgetId: string): string {
  const budgets: Record<string, string> = {
    '15-25k': '15k€ - 25k€',
    '25-40k': '25k€ - 40k€',
    '40-60k': '40k€ - 60k€',
    '60k+': '60k€ et plus'
  }
  return budgets[budgetId] || budgetId
}

function getPriorityName(priorityId: string): string {
  const priorities: Record<string, string> = {
    'speed': 'Vitesse de livraison',
    'quality': 'Qualité et perfection',
    'cost': 'Optimisation des coûts',
    'scalability': 'Scalabilité à long terme'
  }
  return priorities[priorityId] || priorityId
}

function calculateEstimatedPrice(data: any): string {
  let price = 0
  
  // Prix de base selon le type de projet
  const basePrices: Record<string, number> = {
    'web': 15000,
    'mobile': 20000,
    'saas': 25000,
    'ai': 30000
  }
  
  price += basePrices[data.projectType] || 0
  
  // Prix des fonctionnalités
  const featurePrices: Record<string, number> = {
    'user-auth': 2000,
    'dashboard': 3000,
    'payments': 2500,
    'notifications': 1500,
    'analytics': 2000,
    'api': 3500,
    'realtime': 3000,
    'offline': 2000,
    'social': 1500,
    'multilingual': 2500,
    'search': 2000,
    'file-upload': 1500
  }
  
  data.features?.forEach((featureId: string) => {
    price += featurePrices[featureId] || 0
  })
  
  // Multiplicateur de design
  const designMultipliers: Record<string, number> = {
    'simple': 1,
    'standard': 1.3,
    'premium': 1.6
  }
  
  price *= designMultipliers[data.designComplexity] || 1
  
  // Exigences techniques
  const techPrices: Record<string, number> = {
    'scalability': 3000,
    'security': 2500,
    'performance': 2000,
    'monitoring': 1500,
    'backup': 1000
  }
  
  data.technicalRequirements?.forEach((reqId: string) => {
    price += techPrices[reqId] || 0
  })
  
  // Intégrations
  const integrationPrices: Record<string, number> = {
    'stripe': 1000,
    'google-analytics': 500,
    'mailchimp': 800,
    'slack': 600,
    'salesforce': 2000,
    'hubspot': 1500
  }
  
  data.integrations?.forEach((intId: string) => {
    price += integrationPrices[intId] || 0
  })
  
  // Multiplicateur de timeline
  const timelineMultipliers: Record<string, number> = {
    'urgent': 1.5,
    'standard': 1,
    'flexible': 0.9
  }
  
  price *= timelineMultipliers[data.timeline] || 1
  
  return Math.round(price).toLocaleString('fr-FR')
}

function calculateEstimatedTimeline(data: any): string {
  const baseTimelines: Record<string, string> = {
    'web': '6-8 semaines',
    'mobile': '8-12 semaines',
    'saas': '10-16 semaines',
    'ai': '12-20 semaines'
  }
  
  let baseWeeks = 8 // default
  
  switch (data.projectType) {
    case 'web':
      baseWeeks = 7
      break
    case 'mobile':
      baseWeeks = 10
      break
    case 'saas':
      baseWeeks = 13
      break
    case 'ai':
      baseWeeks = 16
      break
  }
  
  // Ajustement selon la timeline
  switch (data.timeline) {
    case 'urgent':
      baseWeeks = Math.round(baseWeeks * 0.6)
      break
    case 'flexible':
      baseWeeks = Math.round(baseWeeks * 1.3)
      break
  }
  
  const minWeeks = Math.round(baseWeeks * 0.8)
  const maxWeeks = baseWeeks
  
  return `${minWeeks}-${maxWeeks} semaines`
}