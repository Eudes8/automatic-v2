import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const proposalId = searchParams.get('proposalId')
    
    if (!proposalId) {
      return NextResponse.json(
        { error: 'ID de proposition manquant' },
        { status: 400 }
      )
    }

    // Simulation de récupération depuis la base de données
    // Dans une vraie application, cela viendrait de PostgreSQL/Prisma
    const mockProposals = {
      'PROP-2024-001': {
        id: 'PROP-2024-001',
        projectName: 'Application E-commerce Mobile',
        company: 'TechShop SARL',
        email: 'contact@techshop.fr',
        phone: '+33 1 23 45 67 89',
        description: 'Application mobile de e-commerce avec paiement intégré et gestion des stocks',
        projectType: 'mobile',
        price: 25000,
        timeline: '10-14 semaines',
        features: [
          'Authentification utilisateurs',
          'Tableau de bord',
          'Intégration paiements',
          'Notifications push/email',
          'Analytics et reporting',
          'API RESTful'
        ],
        status: 'pending',
        createdAt: new Date().toISOString(),
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      }
    }
    
    const proposal = mockProposals[proposalId as keyof typeof mockProposals]
    
    if (!proposal) {
      return NextResponse.json(
        { error: 'Proposition non trouvée' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({
      success: true,
      proposal
    })
    
  } catch (error) {
    console.error('Erreur lors de la récupération de la proposition:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la récupération de la proposition' },
      { status: 500 }
    )
  }
}