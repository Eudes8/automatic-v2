import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const proposalData = await request.json()
    
    // Validation des données
    if (!proposalData.projectName || !proposalData.email || !proposalData.description) {
      return NextResponse.json(
        { error: 'Données manquantes pour la proposition' },
        { status: 400 }
      )
    }

    // Génération d'un ID unique pour la proposition
    const proposalId = `PROP-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
    
    // Simulation de sauvegarde en base de données
    // Dans une vraie application, cela sauvegarderait dans PostgreSQL/Prisma
    const savedProposal = {
      id: proposalId,
      ...proposalData,
      status: 'pending',
      createdAt: new Date().toISOString(),
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    }
    
    // Simulation d'un délai de traitement
    await new Promise(resolve => setTimeout(resolve, 500))
    
    console.log('Proposition sauvegardée:', savedProposal)
    
    return NextResponse.json({
      success: true,
      message: 'Proposition sauvegardée avec succès',
      proposalId,
      proposal: savedProposal
    })
    
  } catch (error) {
    console.error('Erreur lors de la sauvegarde de la proposition:', error)
    return NextResponse.json(
      { error: 'Erreur lors de la sauvegarde de la proposition' },
      { status: 500 }
    )
  }
}