"use client"

import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Badge } from '@/components/ui/badge'
import { 
  Shield, 
  Eye, 
  EyeOff, 
  Mail, 
  Download,
  Calendar,
  CheckCircle2,
  AlertCircle,
  User,
  Database,
  Globe,
  Lock,
  FileText
} from 'lucide-react'
import Link from 'next/link'

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    subject: '',
    message: '',
    type: 'commercial'
  })
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Simulation d'envoi du formulaire
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      setSubmitted(true)
      setFormData({
        name: '',
        email: '',
        phone: '',
        company: '',
        subject: '',
        message: '',
        type: 'commercial'
      })
    } catch (error) {
      console.error('Erreur lors de l\'envoi:', error)
    } finally {
      setLoading(false)
    }
  }

  const subjectOptions = [
    { value: 'commercial', label: 'Commercial - Devis et projets' },
    { value: 'technical', label: 'Support technique' },
    { value: 'partnership', label: 'Partenariat' },
    { value: 'careers', label: 'Carrières' },
    { value: 'other', label: 'Autre' }
  ]

  const offices = [
    {
      city: 'Paris',
      address: '456 Avenue de l\'Innovation, 75002 Paris',
      phone: '+33 1 23 45 67 89',
      email: 'paris@automatic.dev',
      hours: 'Lun-Ven: 9h-18h'
    },
      {
      city: 'Lyon',
      address: '123 Rue de la Tech, 69000 Lyon',
      phone: '+33 4 78 90 12 34',
      email: 'lyon@automatic.dev',
      hours: 'Lun-Ven: 9h-18h'
    }
    }

  const team = [
    {
      name: 'Équipe Commerciale',
      description: 'Pour vos projets, devis et questions commerciales',
      icon: Users,
      email: 'commercial@automatic.dev',
      phone: '+33 1 23 45 67 89',
    },
      {
      name: 'Support Technique',
      description: 'Pour l\'assistance technique et les incidents',
      icon: Headset,
      email: 'support@automatic.dev',
      phone: '+33 1 23 45 67 88'
    },
      {
      name: 'Équipe Partenaires',
      description: 'Pour les opportunités de partenariat',
      icon: Building,
      email: 'partners@automatic.dev',
      phone: '+33 1 23 45 67 87'
    }
    ]

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Send className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl text-green-600">Message envoyé !</CardTitle>
            <CardDescription>
              Nous vous répondrons dans les plus brefs délais.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Merci pour votre intérêt. Notre équipe va étudier votre demande et vous recontactera rapidement.
            </p>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                <strong>Prochaines étapes :</strong>
              </p>
              <ul className="text-sm text-muted-foreground space-y-1 text-left">
                <li>• Réception et analyse de votre demande</li>
                <li>• Prise de contact par l&apos;équipe appropriée</li>
                <li>• Proposition de solution adaptée</li>
                <li>• Démarrage du projet si accord</li>
              </ul>
              </ul>
            </div>
            </div>
            <div className="flex space-x-4">
              <Button variant="outline" asChild>
                <Link href="/">
                  Retour à l&apos;accueil
                </Link>
              </Button>
              <Button asChild>
                <Link href="/configurateur">
                  Configurer mon projet
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  )

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-background to-secondary/5">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="secondary" className="mb-6">
              Contactez-nous
            </Badge>
            <h1 className="text-4xl lg:text-6xl font-bold text-foreground mb-6">
              Parlons de votre
              <span className="text-primary"> projet</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Notre équipe est à votre écoute pour transformer vos idées en réalité digitale.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MessageSquare className="w-5 h-5" />
                    <span>Envoyez-nous un message</span>
                  </CardTitle>
                  <CardDescription>
                    Remplissez le formulaire ci-dessous et nous vous répondrons dans les 24h.
                  </CardDescription>
                </CardHeader>
                </CardHeader>
                <CardContent className="space-y-6">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Nom complet *</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => handleInputChange('name', e.target.value)}
                          placeholder="Jean Dupont"
                          required
                        />
                      </div>
                      </div>
                      <div>
                        <Label htmlFor="email">Email *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange('email', e.target.value)}
                          placeholder="jean.dupont@email.com"
                          required
                        />
                      </div>
                    </div>
                      <div>
                        <Label htmlFor="phone">Téléphone</Label>
                          <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) => handleInputChange('phone', e.target.value)}
                          placeholder="+33 1 23 45 67 89"
                          required
                        />
                      </div>
                    </div>
                    </div>

                    <div>
                      <Label htmlFor="company">Entreprise</Label>
                        <Input
                          id="company"
                          value={formData.company}
                          onChange={(e) => handleInputChange('company', e.target.value)}
                          placeholder="TechShop SARL"
                        />
                      </div>
                    </div>

                    <div>
                      <div>
                      <Label htmlFor="subject">Sujet *</Label>
                      <RadioGroup value={formData.type} onValueChange={(value) => handleInputChange('type', value)}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {subjectOptions.map((option) => (
                            <div key={option.value} className="flex items-center space-x-2">
                              <RadioGroupItem value={option.value} id={option.value} />
                              <Label htmlFor={option.value} className="text-sm">
                                {option.label}
                              </Label>
                            </div>
                          ))}
                        </div>
                      </RadioGroup>
                    </div>

                    <div>
                      <Label htmlFor="subject">Sujet du message *</Label>
                      <Input
                        id="subject"
                        value={formData.subject}
                        onChange={(e) => handleInputChange('subject', e.target.value)}
                        placeholder="Demande de devis pour application mobile"
                        required
                      />
                      </div>

                    <div>
                      <Label htmlFor="message">Message *</Label>
                      <Textarea
                        id="message"
                        value={formData.message}
                        onChange={(e) => handleInputChange('message', e.target.value)}
                        placeholder="Décrivez votre projet, vos besoins spécifiques, votre budget, vos délais..."
                        rows={6}
                        required
                      />
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full" 
                      size="lg"
                      disabled={loading}
                    >
                      {loading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          Envoi en cours...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Envoyer le message
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Quick Contact */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Contact rapide</CardTitle>
                  <CardDescription>
                    Pour une réponse immédiate
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3 text-sm">
                    <Mail className="w-4 h-4 text-primary" />
                    <span>contact@automatic.dev</span>
                  </div>
                    <div className="flex items-center space-x-3">
                      <Phone className="w-4 h-4 text-primary" />
                      <span>+33 1 23 45 67 89</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Clock className="w-4 h-4 text-primary" />
                      <span>Lun-Ven: 9h-18h</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Phone className="w-4 h-4 text-primary" />
                      <span>+33 1 23 45 67 89</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Team */}
              <Card>
                <CardHeader>
                  <CardTitle>Équipes spécialisées</CardTitle>
                  <CardDescription>
                    Contactez directement l&apos;équipe appropriée
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {team.map((member) => (
                    <div key={member.name} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <member.icon className="w-5 h-5 text-primary" />
                        <div className="flex-1">
                          <h4 className="font-medium text-foreground">{member.name}</h4>
                          <p className="text-sm text-muted-foreground mb-2">{member.description}</p>
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <Mail className="w-3 h-3 text-muted-foreground" />
                              <span>{member.email}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Phone className="w-3 h-3 text-muted-foreground" />
                              <span>{member.phone}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Offices */}
              <Card>
                <CardHeader>
                  <CardTitle>Nos bureaux</CardTitle>
                  <CardDescription>
                    Venez nous rencontrer dans nos locaux
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {offices.map((office) => (
                    <div key={office.city} className="p-4 border rounded-lg">
                      <h4 className="font-medium text-foreground mb-2">{office.city}</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-start space-x-2">
                          <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                          <span>{office.address}</span>
                        </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Phone className="w-3 text-muted-foreground" />
                          <span>{office.phone}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Mail className="w-3 h-3 text-muted-foreground" />
                          <span>{office.hours}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                              <Clock className="w-3 text-muted-foreground" />
                              <span>{office.email}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Footer */}
              <section className="py-8 border-t border-border/50">
                <div className="container mx-auto px-4 lg:px-8">
                  <div className="text-center text-sm text-muted-foreground">
                    <p>
                      Cette politique de confidentialité s&apos;applique à l&apos;ensemble du site web d&apos;AUTOMATIC accessible à l&apos;URL suivante : https://automatic.dev
                    </p>
                    </p>
                    <div className="flex justify-center space-x-6 mt-4">
                      <Link href="/mentions-legales" className="hover:text-primary transition-colors">
                        Mentions légales
                      </Link>
                      <Link href="/politique-confidentialite" className="hover:text-primary transition-colors">
                        Politique de confidentialité
                      </Link>
                      <Link href="/cookies" className="hover:text-primary transition-colors">
                        Politique de cookies
                      </Link>
                      <Link href="/cgu" className="hover:text-primary transition-colors">
                        CGU
                      </Link>
                      <Link href="/contact" className="hover:text-primary transition-colors">
                        Contact
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default PolitiqueConfidentialite