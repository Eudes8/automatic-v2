"use client"

import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Badge } from '@/components/ui/badge'
import { 
  Shield, 
  Eye, 
  EyeOff, 
  Mail, 
  Download,
  Calendar,
  CheckCircle2,
  AlertCircle,
  User,
  Database,
  Globe,
  Lock,
  FileText
} from 'lucide-react'
import Link from 'next/link'

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    subject: '',
    message: '',
    type: 'commercial'
  })
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Simulation d'envoi du formulaire
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      setSubmitted(true)
      setFormData({
        name: '',
        email: '',
        phone: '',
        company: '',
        subject: '',
        message: '',
        type: 'commercial'
      })
    } catch (error) {
      console.error('Erreur lors de l\'envoi:', error)
    } finally {
      setLoading(false)
    }
  }

  const subjectOptions = [
    { value: 'commercial', label: 'Commercial - Devis et projets' },
    { value: 'technical', label: 'Support technique' },
    { value: 'partnership', label: 'Partenariat' },
    { value: 'careers', label: 'Carrières' },
    { value: 'other', label: 'Autre' }
  ]

  const offices = [
    {
      city: 'Paris',
      address: '456 Avenue de l\'Innovation, 75002 Paris',
      phone: '+33 1 23 45 67 89',
      email: 'paris@automatic.dev',
      hours: 'Lun-Ven: 9h-18h'
    },
      {
      city: 'Lyon',
      address: '123 Rue de la Tech, 69000 Lyon',
      phone: '+33 4 78 90 12 34',
      email: 'lyon@automatic.dev',
      hours: 'Lun-Ven: 9h-18h'
    }
    }

  const team = [
    {
      name: 'Équipe Commerciale',
      description: 'Pour vos projets, devis et questions commerciales',
      icon: Users,
      email: 'commercial@automatic.dev',
      phone: '+33 1 23 45 67 89'
    },
      {
      name: 'Support Technique',
      description: 'Pour l\'assistance technique et les incidents',
      icon: Headset,
      email: 'support@automatic.dev',
      phone: '+33 1 23 45 67 88'
    },
      {
      name: 'Équipe Partenaires',
      description: 'Pour les opportunités de partenariat',
      icon: Building,
      email: 'partners@automatic.dev',
      phone: '+33 1 23 45 67 87'
    }
    }
  ]

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Send className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl text-green-600">Message envoyé !</CardTitle>
            <CardDescription>
              Nous vous répondrons dans les plus brefs délais.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-muted-foreground">
              Merci pour votre intérêt. Notre équipe va étudier votre demande et vous recontactera rapidement.
            </p>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                <strong>Prochaines étapes :</strong>
              </p>
              <ul className="text-sm text-muted-foreground space-y-1 text-left">
                <li>• Réception et analyse de votre demande</li>
                <li>• Prise de contact par l&apos;équipe appropriée</li>
                <li>• Proposition de solution adaptée</li>
                <li>• Démarrage du projet si accord</li>
              </ul>
              </ul>
            </div>
            </div>
            <div className="flex space-x-4">
              <Button variant="outline" asChild>
                <Link href="/">
                  Retour à l&apos;accueil
                </Link>
              </Button>
              <Button asChild>
                <Link href="/configurateur">
                  Configurer un projet
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  )
}

export default Contact